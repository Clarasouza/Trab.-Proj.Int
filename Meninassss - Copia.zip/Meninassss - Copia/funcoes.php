<?php
error_reporting(0);
session_start();
function listaResenhas(){
	$resenha= array();

	$dados= file("dados.csv");

	foreach ($dados as $posicao => $linha) {
		if ($posicao !=0) {
			$colunas= explode(";",$linha);
			$resenha['cod'] =$colunas[0];
			$resenha['nome'] =$colunas[1];
			$resenha['imagem1'] =$colunas[2];
			$resenha['imagem2'] =$colunas[3];
			$resenha['info'] =$colunas[4];
			$resenha['categoria'] =$colunas[5];
			$resenha['icone'] =$colunas[6];
			$resenha['resenha'] =$colunas[7];
			$resenhas[]=$resenha;
		}
	}
	return $resenhas;
}

function buscaResenha($codigo){
	$resenha= array();
	$dados= file("dados.csv");
	foreach ($dados as $linha) {
		$colunas= explode(";",$linha);
		if($colunas[0]==$codigo){
			$resenha['cod'] =$colunas[0];
			$resenha['nome'] =$colunas[1];
			$resenha['imagem1'] =$colunas[2];
			$resenha['imagem2'] =$colunas[3];
			$resenha['info'] =$colunas[4];
			$resenha['categoria'] =$colunas[5];
			$resenha['icone'] =$colunas[6];
			$resenha['resenha'] =$colunas[7];
			$resenha['autor']=$colunas[8];
		}
	}
	
	return $resenha;
}

function listaCategoria(){
	$categoria= array();
	$dados= file("categorias.csv");
	foreach ($dados as $posicao => $linha) {
		if ($posicao !=0) {
			$colunas= explode(";",$linha);
			$categoria['cod'] =$colunas[0];
			$categoria['categoria'] =$colunas[1];
			$categorias[]=$categoria;
		}
	}
	return $categorias;
}

function buscaCategoria($codigo){
	$categoria=array();
	$dados= file("dados.csv");
	foreach ($dados as $linha) {
		$dados=explode(";",$linha);
		if($dados[5]==$codigo){
			$categoria['cod'] =$dados[0];
			$categoria['nome'] =$dados[1];
			$categoria['imagem1'] =$dados[2];
			$categoria['imagem2'] =$dados[3];
			$categoria['info'] =$dados[4];
			$categoria['categoria'] =$dados[5];
			$categoria['icone'] =$dados[6];
			$categoria['resenha'] =$dados[7];
			$categorias[]=$categoria;
		}
	}
	return $categorias;
}

function testaUsuario($user,$senha){
	$dados= file("usuarios.csv");
	$todosDados=[];
	foreach ($dados as $linha) {
		$dados=explode(";",$linha);
		$todosDados[]=$dados;
	}
	$cont=0;
	foreach ($todosDados as $key) {
		if ($key[5]==$user) {
			$cont++;
			$guarda=$key[6];
			$_SESSION['nome']=$key[5];
		}
	}
	if($cont==0){
		$retorna=0;
		return $retorna;
	}elseif($guarda==$senha) {
		$_SESSION['logado']=1;
		$retorna=1;
		return $retorna;
	}else{
		$retorna=0;
		return $retorna;
	}	
} 

function InfoUsuario($codigo){
	$usuarios=array();
	$dados= file("usuarios.csv");
	foreach ($dados as $linha) {
		$dados=explode(";",$linha);
		if($dados[0]==$codigo){
			$usuario['cod_usu']=$dados[0];
			$usuario['nome'] =$dados[1];
			$usuario['email'] =$dados[4];
			$usuario['usuario'] =$dados[5];
			$usuario['senha'] =$dados[6];
			$usuarios[]=$usuario;
		}
	}
	return $usuarios;
}











function verifica_curtir($cod_usu,$cod_resenha){
    $verifica_curtidas = file_get_contents('dados/curtidas.json');
    $lista_curtidas = json_decode($verifica_curtidas,true);
    $esta_curtida = false;
    foreach ($lista_curtidas as $like){
        if ($like['usuario'] == $cod_usu AND $like['resenha'] == $cod_resenha AND $like['curtiu'] == true){
            $esta_curtida = true;
        }
    }
     return($esta_curtida);
}

function curtir($cod_usu,$cod_resenha){

    if (isset ($_GET['acao']) AND $_GET['acao'] == "curtir"){
        $curtidas = array();
        $curtida = [
            "resenha" => $cod_resenha,
            "usuario" => $cod_usu,
            "curtiu"  => true
        ];
        $curtidas[] = $curtida;
        $curtidas_json = json_encode($curtidas, JSON_PRETTY_PRINT);
        file_put_contents('dados/curtidas.json', $curtidas_json);
    }
}

function remover($cod_usu,$cod_resenha){

    if (isset ($_GET['acao']) AND $_GET['acao'] == "remover"){
        $curtidas = array();
        $curtida = [
            "resenha" => $cod_resenha,
            "usuario" => $cod_usu,
            "curtiu"  => false
        ];
        $curtidas[] = $curtida;
        $curtidas_json = json_encode($curtidas, JSON_PRETTY_PRINT);
        file_put_contents('dados/curtidas.json', $curtidas_json);
    }
}