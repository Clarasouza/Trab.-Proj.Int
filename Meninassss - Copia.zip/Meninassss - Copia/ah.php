<?php
include "cabecalho.php";
$cod=$_SESSION['nome'];
$dadosusu=InfoUsuario($cod);
print($dadosusu['cod_usu']);
?>