<?php 
include("cabecalho.php");
include 'slider2.php';
?>
<h1 class="centra black">JOGOS</h1>
<div class="ui grid center aligned page grid ">
  <?php
  $lista=listaResenhas();
  $ver=rand(16,16);
  foreach ($lista as $dados) {
    if ($dados['cod']<=$ver) {
      echo('
      <div class="four wide column ">
      <div class="ui special cards">
      <div class="ui card">
      <div class="blurring dimmable image">
      <div class="ui dimmer">
        <div class="content">
          <div class="center">
      <a href="detalhaResenha.php?cod='.$dados['cod'].'">
            <div class="ui inverted button">Visualizar</div>
      </a>
  </div>

          <br>
       <div class="ui button">
       <div class="ui heart rating" data-max-rating="1">
       </div>
       </div>
        </div>


      </div>
      <div class="ui image">
      <img src="imagens/'.$dados['imagem1'].'" class="visible content">
      </div>
      </div>
      <div class="content">
      <a class="header" href="detalhaResenha.php?cod='.$dados['cod'].'">'.$dados['nome'].'</a>
      <div class="meta">
      <span class="date">'.$dados['info'].'</span>
      </div>
      </div>
      </div>
      </div>
      </div>
      '); 
    }
  }

 

if(!isset($_SESSION['login'])){

}else{

$cod_usu = $_SESSION['cod_usu'];

$esta_curtida = verifica_curtir($cod_usu,1);

    if($esta_curtida != true) { ?>

    <a href="?acao=curtir"><div class="ui heart rating" data-rating="0" data-max-rating="1"></div></a>

<?php

    curtir($cod_usu,1);


    }else { ?>

     <a href="?acao=remover"><div class="ui heart rating" data-rating="1" data-max-rating="1"></div></a>

    
<?php 


    remover($cod_usu,1);

    } 
}?>
  ?>
</div> 
</div>
<?php
include "rodape.php";
?>


