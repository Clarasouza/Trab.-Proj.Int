<link rel="stylesheet" type="text/css" href="css/slider2.css">
<div class="CSSgal">

  <s id="s1"></s> 
  <s id="s2"></s>
  <s id="s3"></s>
  <s id="s4"></s>

  <div class="slider">
    <div>
			 <img class="foto" src="imagens/alo.png">
		</div>
    <div>
      
      <img class="foto" src="imagens/belo.png">
		</div>
    <div>
      <img class="foto" src="imagens/demo.jpg">
		</div>
    <div>
      <img class="foto" src="imagens/not.jpg">      
		</div>
  </div>
  
  <div class="prevNext">
    <div><a href="#s4"></a><a href="#s2"></a></div>
    <div><a href="#s1"></a><a href="#s3"></a></div>
    <div><a href="#s2"></a><a href="#s4"></a></div>
    <div><a href="#s3"></a><a href="#s1"></a></div>
  </div>

  <div class="bullets">
    <a href="#s1"></a>
    <a href="#s2"></a>
    <a href="#s3"></a>
    <a href="#s4"></a>
  </div>

</div>